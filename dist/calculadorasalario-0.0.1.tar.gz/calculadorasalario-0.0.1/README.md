# calculo_salario

O pacote pode ser utilizado para calcular o valor do pagamento do salario

## Instalação

```bash
pip install calculo_salario
```

## Uso

```python
from calculo_salario import calc_pagamento
```

## Autor
Isabela Rossetti

## Licenca
[MIT](https://choosealicense.com/licenses/mit/)